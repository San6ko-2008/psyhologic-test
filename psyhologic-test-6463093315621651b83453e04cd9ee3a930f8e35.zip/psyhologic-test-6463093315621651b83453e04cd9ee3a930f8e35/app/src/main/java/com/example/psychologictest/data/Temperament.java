package com.example.psychologictest.data;

public enum Temperament {
    SANGUINE, PHLEGMATIC, CHOLERIC, MELANCHOLIC
}
